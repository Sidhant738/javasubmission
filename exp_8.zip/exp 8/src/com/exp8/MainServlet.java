package com.exp8;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class MainServlet extends HttpServlet {
  private static final String USERNAME = "admin";
  private static final String PASSWORD = "12345";

  @SuppressWarnings("unchecked")
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
    String action = req.getParameter("action");
    ServletContext context = getServletContext();
    req.setCharacterEncoding("UTF-8");
    res.setCharacterEncoding("UTF-8");

    if ("login".equals(action)) {
      String user = req.getParameter("username");
      String pass = req.getParameter("password");

      if (USERNAME.equals(user) && PASSWORD.equals(pass)) {
        // initialize employees if not present
        List<String[]> employees = (List<String[]>) context.getAttribute("employees");
        if (employees == null) {
            employees = new ArrayList<>();
            employees.add(new String[]{"1", "John Doe", "HR", "50000"});
            employees.add(new String[]{"2", "Jane Smith", "IT", "65000"});
            employees.add(new String[]{"3", "Ravi Kumar", "Finance", "55000"});
            context.setAttribute("employees", employees);
        }
        res.sendRedirect("employees.jsp");
      } else {
        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();
        out.println("<h3>Invalid Credentials</h3>");
        out.println("<a href='index.html'>Try Again</a>");
      }
    }

    else if ("markAttendance".equals(action)) {
      String student = req.getParameter("student_name");
      String status = req.getParameter("status");

      List<String[]> attendance = (List<String[]>) context.getAttribute("attendance");
      if (attendance == null) {
        attendance = new ArrayList<>();
      }
      attendance.add(new String[]{student, status});
      context.setAttribute("attendance", attendance);

      req.setAttribute("msg", "Attendance Marked Successfully");
      RequestDispatcher rd = req.getRequestDispatcher("attendance.jsp");
      rd.forward(req, res);
    }
  }

  protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
    // simple redirect to index
    res.sendRedirect("index.html");
  }
}
