exp 8 - Eclipse Dynamic Web Project (Java 11)
-------------------------------------------

Contents:
- .project
- .classpath
- src/com/exp8/MainServlet.java
- WebContent/index.html
- WebContent/employees.jsp
- WebContent/attendance.jsp
- WebContent/WEB-INF/web.xml

Import instructions (Eclipse):
1. File -> Import -> Existing Projects into Workspace.
2. Select root directory: /mnt/data/exp 8
3. Make sure a Tomcat runtime (Tomcat 9 or 10) is configured with Java 11.
4. Right-click project -> Properties -> Targeted Runtimes -> check your Tomcat.
5. Run on Server.

Default credentials:
- username: admin
- password: 12345

Notes:
- This project uses in-memory storage (application scope). No database required.
- To persist data across server restarts, integrate a database or file storage.
