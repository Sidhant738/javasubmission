package com.example.exp9.student;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping
    public List<Student> all() {
        return studentService.getAll();
    }

    @GetMapping("/{id}")
    public Student byId(@PathVariable Long id) {
        return studentService.getById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Student create(@RequestBody Student student) {
        return studentService.create(student);
    }

    @PutMapping("/{id}")
    public Student update(@PathVariable Long id, @RequestBody Student updates) {
        return studentService.update(id, updates);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        studentService.delete(id);
    }

    @PostMapping("/tx-demo")
    public void txDemo() {
        Student s1 = new Student();
        s1.setName("Alice");
        s1.setEmail("alice@example.com");
        Student s2 = new Student();
        s2.setName("Bob");
        s2.setEmail("bob@example.com");
        try {
            studentService.createTwoThenFail(s1, s2);
        } catch (RuntimeException ignored) {
            // swallow for demo; data should be rolled back
        }
    }
}


