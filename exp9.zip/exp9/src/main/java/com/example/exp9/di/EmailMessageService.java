package com.example.exp9.di;

public class EmailMessageService implements MessageService {
    @Override
    public String formatMessage(String recipient, String messageBody) {
        return "Email to " + recipient + ": " + messageBody;
    }
}


