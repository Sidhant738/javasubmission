package com.example.exp9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp9Application {

    public static void main(String[] args) {
        SpringApplication.run(Exp9Application.class, args);
    }
}


