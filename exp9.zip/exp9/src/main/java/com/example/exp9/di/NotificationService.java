package com.example.exp9.di;

public class NotificationService {
    private final MessageService messageService;

    public NotificationService(MessageService messageService) {
        this.messageService = messageService;
    }

    public String notifyUser(String recipient, String messageBody) {
        return messageService.formatMessage(recipient, messageBody);
    }
}


