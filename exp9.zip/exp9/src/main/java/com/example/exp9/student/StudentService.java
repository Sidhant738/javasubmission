package com.example.exp9.student;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class StudentService {
    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Transactional(readOnly = true)
    public List<Student> getAll() {
        return studentRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Student getById(Long id) {
        return studentRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Student not found: " + id));
    }

    @Transactional
    public Student create(Student student) {
        studentRepository.findByEmail(student.getEmail()).ifPresent(s -> {
            throw new IllegalArgumentException("Email already exists: " + s.getEmail());
        });
        return studentRepository.save(student);
    }

    @Transactional
    public Student update(Long id, Student updates) {
        Student existing = getById(id);
        existing.setName(updates.getName());
        existing.setEmail(updates.getEmail());
        return studentRepository.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        studentRepository.deleteById(id);
    }

    @Transactional
    public void createTwoThenFail(Student s1, Student s2) {
        studentRepository.save(s1);
        if (true) {
            throw new RuntimeException("Forcing rollback after first save");
        }
        // This line is never reached, but demonstrates atomicity
        // studentRepository.save(s2);
    }
}


