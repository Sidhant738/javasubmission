package com.example.exp9.di;

public interface MessageService {
    String formatMessage(String recipient, String messageBody);
}


