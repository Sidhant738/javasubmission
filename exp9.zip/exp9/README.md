# Exp9: Spring DI + Hibernate Student CRUD + Transactions

## Run

```bash
mvn spring-boot:run
```

App starts on http://localhost:8080

## Part A: Dependency Injection (Java Config)
- Beans defined in `com.example.exp9.di.AppConfig`
- Demo output printed on startup by `DiDemoRunner`

## Part B: Student CRUD (Hibernate via Spring Data JPA)
- Entity: `com.example.exp9.student.Student`
- Repository: `StudentRepository`
- Service: `StudentService`
- Controller Endpoints:
  - GET `/api/students`
  - GET `/api/students/{id}`
  - POST `/api/students`
  - PUT `/api/students/{id}`
  - DELETE `/api/students/{id}`

Example create:
```bash
curl -X POST http://localhost:8080/api/students \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice","email":"alice@example.com"}'
```

## Part C: Transaction Management
- `StudentService#createTwoThenFail` annotated with `@Transactional`
- POST `/api/students/tx-demo` triggers a forced exception after first save; transaction rolls back so no students are persisted.

## DB
- H2 in-memory; console at `/h2-console` (JDBC URL: `jdbc:h2:mem:exp9db`)

